﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lisa_1
{
    public partial class Form1 : Form
    {
        public String nome;
        public int idade;
        public double salario;

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnChecar_Click(object sender, EventArgs e)
        {
            
            try
            {
                nome = txtNome.Text;
                idade = Convert.ToInt32(txtIdade.Text);
                salario = Convert.ToDouble(txtSalario.Text);
                MessageBox.Show("Nome: " + nome + "\nIdade: " + idade + "\nsalario: " + salario + "\nData de Nascimento" +
                    ": " + dateTimePicker1.Value.ToString().Substring(0,10));
            }
            catch(Exception)
            {
                MessageBox.Show("Foda-se");
            }
        }

    }
}
