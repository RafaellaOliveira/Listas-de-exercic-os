﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista_3
{
    public partial class Form1 : Form
    {
        public int g;
        public int c;
        Random rn = new Random();
        public Queue<int> fila = new Queue<int>();
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnGerar_Click(object sender, EventArgs e)
        {
            g = rn.Next(0, 200);
            fila.Enqueue(g);
            lblSenha.Text = Convert.ToString(g);
        }

        private void BtnChamar_Click(object sender, EventArgs e)
        {
            try
            {
                if (fila != null)
                {
                    lblChamar.Text = Convert.ToString(fila.Dequeue());
                }
            }
            catch
            {
                lblChamar.Text = "N/A";
            }
        }
    }
}
