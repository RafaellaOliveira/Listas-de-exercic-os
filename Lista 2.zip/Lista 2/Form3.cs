﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista_2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        public double Arredonda(double num)
        {
            
            return Math.Ceiling(num);
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Arredonda(Convert.ToDouble(txtNumero.Text)).ToString());
        }
    }
}
